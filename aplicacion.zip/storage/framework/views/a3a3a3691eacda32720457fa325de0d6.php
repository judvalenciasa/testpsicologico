<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Respuestas</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/reporte_respuestas.css')); ?>">
</head>
<body>
    <?php echo $__env->make('shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="reporte_respuestas_section">
        <div class="report-header">
            <div>
                <h1>Reporte de Respuestas</h1>
                <p class="subtitle">Detalle de respuestas y subrespuestas del usuario seleccionado.</p>
            </div>
            <div class="summary-chips">
                <span class="chip">Respuestas calificables: <?php echo e($respuestasCalificables ?? 0); ?></span>
                <span class="chip">Subrespuestas calificables: <?php echo e($subrespuestasCalificables ?? 0); ?></span>
            </div>
        </div>

        <div class="table-card">
            <h2 class="table-title">Respuestas</h2>
            <?php
                $itemsFiltrables = collect($informe['respuestas'])
                    ->concat($informe['subrespuestas']);
                $habilidades = $itemsFiltrables
                    ->pluck('habilidad')
                    ->filter()
                    ->unique()
                    ->sort()
                    ->values();
                $subhabilidades = $itemsFiltrables
                    ->pluck('subhabilidad')
                    ->filter()
                    ->unique()
                    ->sort()
                    ->values();
            ?>
            <div class="answers-filters" aria-label="Filtros de respuestas">
                <label>
                    <span>Calificación</span>
                    <select id="filter-calificacion">
                        <option value="">Todas</option>
                        <option value="0">Solo calificación 0</option>
                        <option value="1">Solo calificación 1</option>
                    </select>
                </label>
                <label>
                    <span>Habilidad</span>
                    <select id="filter-habilidad">
                        <option value="">Todas</option>
                        <?php $__currentLoopData = $habilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habilidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($habilidad); ?>"><?php echo e($habilidad); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>
                    <span>Subhabilidad</span>
                    <select id="filter-subhabilidad">
                        <option value="">Todas</option>
                        <?php $__currentLoopData = $subhabilidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subhabilidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subhabilidad); ?>"><?php echo e($subhabilidad); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <button type="button" id="clear-answer-filters" class="clear-filters-btn">Limpiar filtros</button>
            </div>
            <div class="table-wrapper">
                <table id="tabla-respuestas" class="center">
                    <thead>
                        <tr>
                            <th>Id contexto</th>
                            <th>Habilidad</th>
                            <th>Subhabilidad</th>
                            <th>Contexto</th>
                            <th>Texto de la Pregunta</th>
                            <th>Respuesta</th>
                            <th>Calificación</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $informe['respuestas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr
                            data-pregunta-id="<?php echo e($respuesta['id_pregunta']); ?>"
                            data-calificacion="<?php echo e($respuesta['calificacion']); ?>"
                            data-habilidad="<?php echo e($respuesta['habilidad']); ?>"
                            data-subhabilidad="<?php echo e($respuesta['subhabilidad']); ?>"
                        >
                            <td class="col-id-contexto"><?php echo e($respuesta['id_contexto']); ?></td>
                            <td class="col-habilidad"><?php echo e($respuesta['habilidad']); ?></td>
                            <td class="col-subhabilidad"><?php echo e($respuesta['subhabilidad']); ?></td>
                            <td class="text-cell">
                                <?php
                                    $contextoTexto = (string) ($respuesta['contexto'] ?? '');
                                    $contextoCorto = \Illuminate\Support\Str::limit($contextoTexto, 180);
                                    $mostrarToggle = mb_strlen($contextoTexto) > mb_strlen($contextoCorto);
                                ?>
                                <span id="contexto-<?php echo e($loop->index); ?>" class="context-preview"><?php echo e($contextoCorto); ?></span>
                                <?php if($mostrarToggle): ?>
                                    <button
                                        type="button"
                                        class="toggle-context-btn"
                                        data-target="contexto-<?php echo e($loop->index); ?>"
                                        data-short="<?php echo e($contextoCorto); ?>"
                                        data-full="<?php echo e($contextoTexto); ?>"
                                        data-expanded="false"
                                    >
                                        Mostrar más
                                    </button>
                                <?php endif; ?>
                            </td>
                            <td class="text-cell">
                                <?php
                                    $preguntaTexto = (string) ($respuesta['texto_pregunta'] ?? '');
                                    $preguntaCorta = \Illuminate\Support\Str::limit($preguntaTexto, 180);
                                    $mostrarTogglePregunta = mb_strlen($preguntaTexto) > mb_strlen($preguntaCorta);
                                ?>
                                <span id="pregunta-<?php echo e($loop->index); ?>" class="context-preview"><?php echo e($preguntaCorta); ?></span>
                                <?php if($mostrarTogglePregunta): ?>
                                    <button
                                        type="button"
                                        class="toggle-context-btn"
                                        data-target="pregunta-<?php echo e($loop->index); ?>"
                                        data-short="<?php echo e($preguntaCorta); ?>"
                                        data-full="<?php echo e($preguntaTexto); ?>"
                                        data-expanded="false"
                                    >
                                        Mostrar más
                                    </button>
                                <?php endif; ?>
                            </td>
                            <td class="text-cell">
                                <?php
                                    $respuestaTexto = (string) ($respuesta['respuesta_texto'] ?? '');
                                    $respuestaCorta = \Illuminate\Support\Str::limit($respuestaTexto, 180);
                                    $mostrarToggleRespuesta = mb_strlen($respuestaTexto) > mb_strlen($respuestaCorta);
                                ?>
                                <span id="respuesta-<?php echo e($loop->index); ?>" class="context-preview"><?php echo e($respuestaCorta); ?></span>
                                <?php if($mostrarToggleRespuesta): ?>
                                    <button
                                        type="button"
                                        class="toggle-context-btn"
                                        data-target="respuesta-<?php echo e($loop->index); ?>"
                                        data-short="<?php echo e($respuestaCorta); ?>"
                                        data-full="<?php echo e($respuestaTexto); ?>"
                                        data-expanded="false"
                                    >
                                        Mostrar más
                                    </button>
                                <?php endif; ?>
                            </td>
                            <td class="score-cell"><?php echo e($respuesta['calificacion']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div id="paginacion-respuestas" class="table-pagination"></div>
        </div>

        <div class="table-card">
            <h2 class="table-title">Subrespuestas</h2>
            <div class="table-wrapper">
                <table id="tabla-subrespuestas" class="center subrespuestas-table">
                    <thead>
                        <tr>
                            <th>Habilidad</th>
                            <th>Subhabilidad</th>
                            <th class="col-subrespuesta-texto">Texto subpregunta</th>
                            <th class="col-subrespuesta-respuesta">Respuesta</th>
                            <th class="col-subrespuesta-calificacion">Calificación</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $informe['subrespuestas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subrespuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr
                            data-pregunta-id="<?php echo e($subrespuesta['id_pregunta_principal']); ?>"
                            data-calificacion="<?php echo e($subrespuesta['calificacion_respuesta']); ?>"
                            data-habilidad="<?php echo e($subrespuesta['habilidad']); ?>"
                            data-subhabilidad="<?php echo e($subrespuesta['subhabilidad']); ?>"
                        >
                            <td class="col-habilidad"><?php echo e($subrespuesta['habilidad'] ?? 'Sin dato'); ?></td>
                            <td class="col-subhabilidad"><?php echo e($subrespuesta['subhabilidad'] ?? 'Sin dato'); ?></td>
                            <td class="text-cell col-subrespuesta-texto">
                                <?php
                                    $subpreguntaTexto = (string) ($subrespuesta['texto_subpregunta'] ?? '');
                                    $subpreguntaCorto = \Illuminate\Support\Str::limit($subpreguntaTexto, 160);
                                    $mostrarToggleSubpregunta = mb_strlen($subpreguntaTexto) > mb_strlen($subpreguntaCorto);
                                ?>
                                <span id="subpregunta-<?php echo e($loop->index); ?>" class="context-preview"><?php echo e($subpreguntaCorto); ?></span>
                                <?php if($mostrarToggleSubpregunta): ?>
                                    <button
                                        type="button"
                                        class="toggle-context-btn"
                                        data-target="subpregunta-<?php echo e($loop->index); ?>"
                                        data-short="<?php echo e($subpreguntaCorto); ?>"
                                        data-full="<?php echo e($subpreguntaTexto); ?>"
                                        data-expanded="false"
                                    >
                                        Mostrar más
                                    </button>
                                <?php endif; ?>
                            </td>
                            <td class="text-cell col-subrespuesta-respuesta"><?php echo e($subrespuesta['respuesta']); ?></td>
                            <td class="score-cell col-subrespuesta-calificacion"><?php echo e($subrespuesta['calificacion_respuesta']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div id="paginacion-subrespuestas" class="table-pagination"></div>
        </div>

        <div class="actions-row">
            <a href="<?php echo e(route('private.usuarios')); ?>" class="btn">Volver a Usuarios</a>
        </div>

    </section>
    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        const PAGE_SIZE = 10;

        function setupTablePagination(tableId, paginationId, pageSize, matchesFilter = () => true) {
            const table = document.getElementById(tableId);
            const paginationContainer = document.getElementById(paginationId);
            if (!table || !paginationContainer) {
                return null;
            }

            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            let currentPage = 1;

            function renderRows() {
                const filteredRows = rows.filter(matchesFilter);
                const totalPages = Math.ceil(filteredRows.length / pageSize);
                const safePage = Math.max(1, Math.min(currentPage, Math.max(totalPages, 1)));
                currentPage = safePage;
                const start = (currentPage - 1) * pageSize;
                const end = start + pageSize;
                rows.forEach((row) => {
                    row.style.display = 'none';
                });
                filteredRows.forEach((row, index) => {
                    row.style.display = index >= start && index < end ? '' : 'none';
                });

                return { filteredRows, totalPages };
            }

            function createButton(label, className, onClick, disabled = false, active = false) {
                const button = document.createElement('button');
                button.type = 'button';
                button.textContent = label;
                button.className = className;
                if (active) {
                    button.classList.add('active');
                }
                button.disabled = disabled;
                button.addEventListener('click', onClick);
                return button;
            }

            function renderControls() {
                paginationContainer.innerHTML = '';
                const { filteredRows, totalPages } = renderRows();

                if (filteredRows.length === 0) {
                    paginationContainer.innerHTML = '<span class="pagination-meta">No hay respuestas que coincidan con los filtros.</span>';
                    return;
                }

                if (totalPages <= 1) {
                    return;
                }

                const controls = document.createElement('div');
                controls.className = 'pagination-controls';

                controls.appendChild(
                    createButton(
                        'Anterior',
                        'pagination-btn',
                        () => {
                            if (currentPage > 1) {
                                currentPage--;
                                renderRows();
                                renderControls();
                            }
                        },
                        currentPage === 1
                    )
                );

                for (let page = 1; page <= totalPages; page++) {
                    controls.appendChild(
                        createButton(
                            String(page),
                            'pagination-btn page-number',
                            () => {
                                currentPage = page;
                                renderRows();
                                renderControls();
                            },
                            false,
                            currentPage === page
                        )
                    );
                }

                controls.appendChild(
                    createButton(
                        'Siguiente',
                        'pagination-btn',
                        () => {
                            if (currentPage < totalPages) {
                                currentPage++;
                                renderRows();
                                renderControls();
                            }
                        },
                        currentPage === totalPages
                    )
                );

                const meta = document.createElement('span');
                meta.className = 'pagination-meta';
                meta.textContent = `Página ${currentPage} de ${totalPages}`;

                paginationContainer.appendChild(controls);
                paginationContainer.appendChild(meta);
            }

            renderControls();

            return {
                refresh() {
                    currentPage = 1;
                    renderControls();
                }
            };
        }

        document.addEventListener('DOMContentLoaded', function() {
            const scoreFilter = document.getElementById('filter-calificacion');
            const skillFilter = document.getElementById('filter-habilidad');
            const subskillFilter = document.getElementById('filter-subhabilidad');
            const answerRows = Array.from(document.querySelectorAll('#tabla-respuestas tbody tr'));

            const matchesSkillFilters = (row) => {
                const skillMatches = !skillFilter.value || row.dataset.habilidad === skillFilter.value;
                const subskillMatches = !subskillFilter.value || row.dataset.subhabilidad === subskillFilter.value;

                return skillMatches && subskillMatches;
            };

            // Una subpregunta hereda habilidad y subhabilidad de su pregunta principal.
            // Por eso solo se muestra si la pregunta padre también coincide con esos filtros.
            const parentMatchesSkillFilters = (subanswerRow) => answerRows.some((answerRow) =>
                answerRow.dataset.preguntaId === subanswerRow.dataset.preguntaId &&
                matchesSkillFilters(answerRow)
            );

            const answersPager = setupTablePagination(
                'tabla-respuestas',
                'paginacion-respuestas',
                PAGE_SIZE,
                (row) => {
                    const scoreMatches = !scoreFilter.value || String(row.dataset.calificacion) === scoreFilter.value;

                    return scoreMatches && matchesSkillFilters(row);
                }
            );
            const subanswersPager = setupTablePagination(
                'tabla-subrespuestas',
                'paginacion-subrespuestas',
                PAGE_SIZE,
                (row) => {
                    // La calificación se evalúa en la subrespuesta, según la regla seleccionada.
                    const scoreMatches = !scoreFilter.value || String(row.dataset.calificacion) === scoreFilter.value;

                    return scoreMatches &&
                        matchesSkillFilters(row) &&
                        parentMatchesSkillFilters(row);
                }
            );

            [scoreFilter, skillFilter, subskillFilter].forEach((filter) => {
                filter.addEventListener('change', () => {
                    answersPager?.refresh();
                    subanswersPager?.refresh();
                });
            });

            document.getElementById('clear-answer-filters').addEventListener('click', () => {
                scoreFilter.value = '';
                skillFilter.value = '';
                subskillFilter.value = '';
                answersPager?.refresh();
                subanswersPager?.refresh();
            });
        });

        document.addEventListener('click', function(event) {
            const button = event.target.closest('.toggle-context-btn');
            if (!button) {
                return;
            }

            const targetId = button.dataset.target;
            const targetElement = document.getElementById(targetId);
            if (!targetElement) {
                return;
            }

            const expanded = button.dataset.expanded === 'true';
            if (expanded) {
                targetElement.textContent = button.dataset.short;
                button.textContent = 'Mostrar más';
                button.dataset.expanded = 'false';
            } else {
                targetElement.textContent = button.dataset.full;
                button.textContent = 'Mostrar menos';
                button.dataset.expanded = 'true';
            }
        });
    </script>

</body>
</html>
<?php /**PATH C:\Users\judva\Proyectos\Laragon\laragon\www\testpsicologico\resources\views/reporte/reporte_revisor.blade.php ENDPATH**/ ?>