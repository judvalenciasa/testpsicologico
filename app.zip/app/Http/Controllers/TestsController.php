<?php

namespace App\Http\Controllers;

use App\Application\Tests\AnswerPersistenceService;
use App\Application\Tests\MotivationCategoryService;
use App\Models\Contexto;
use App\Models\Criterios;
use App\Models\Opciones;
use App\Models\opcionessubpreguntas;
use App\Models\Preguntas;
use App\Models\Pruebas;
use App\Models\Reportes;
use App\Models\Respuestas;
use App\Models\Subcriterios;
use App\Models\subpreguntas;
use App\Exceptions\ChatGPTException;
use App\Services\OpenAIService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class TestsController extends Controller
{
    private const ORDEN_INICIAL_CONTEXTO = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29];
    private const PREGUNTAS_ESPECIALES_93 = [93, 94];
    private const PREGUNTAS_ESPECIALES_101 = [101, 102];

    protected $openAIService;
    protected $answerPersistenceService;
    protected $motivationCategoryService;

    public function __construct(
        OpenAIService $openAIService,
        AnswerPersistenceService $answerPersistenceService,
        MotivationCategoryService $motivationCategoryService
    )
    {
        $this->openAIService = $openAIService;
        $this->answerPersistenceService = $answerPersistenceService;
        $this->motivationCategoryService = $motivationCategoryService;
    }

    //funcion para guardar subrespuestas
    public function guardarRespuestaSubpregunta(Request $request, $user, $id_subpregunta, $respuesta, $calificacion)
    {
        $id_reporte = $this->currentReportId();

        try {
            $this->answerPersistenceService->saveSubAnswer($user, $id_subpregunta, $id_reporte, $respuesta, $calificacion);
        } catch (\Throwable $th) {
            return redirect()->back()->withErrors(['msg' => 'Ocurrió un error al guardar la pregunta.']);
        }
    }

    //funcion para guardar respuesta
    public function guardarRespuesta(Request $request, $user, $pregunta_id, $respuesta, $calificacion)
    {
        $id_reporte = $this->currentReportId();

        try {
            $this->answerPersistenceService->saveAnswer($user, $pregunta_id, $id_reporte, $respuesta, $calificacion);
        } catch (\Throwable $th) {
            return redirect()->back()->withErrors(['msg' => 'Ocurrió un error al guardar la pregunta.']);
        }
    }


    // Función para mostrar la página de metacognición
    public function metacognicion($tiempo_prueba, $id_reporte)
    {
        return view('private.metacognicion', compact("tiempo_prueba", "id_reporte"));
    }

    // Función para guardar las respuestas de motivacion
    public function guardar_motivacion(Request $request)
    {
        $categorias_motivacion = $this->sumar_categorias_motivacion($request);

        $id_reporte = session('id_reporte');

        $reporte = Reportes::where('id_reporte', $id_reporte)->first();

        if ($reporte) {

            try {
                $reporte->update([
                    'motivacion_intrinseca' => $categorias_motivacion['motivacion_intrinseca'],
                    'motivacion_extrinseca' => $categorias_motivacion['motivacion_extrinseca'],
                ]);
            } catch (\Throwable $th) {
                return response()->json(['error' => 'No se pudo guardar la motivación.'], 500);
            }
        }

        return $this->cargarPreguntas($request);
    }

    /**
     * Suma las categorías de las respuestas del request y retorna una 
     * lista de categorias con su correspondiente suma
     */
    private function sumar_categorias_motivacion(Request $request)
    {
        return $this->motivationCategoryService->sum($request->all());
    }

    // Función para mostrar la página de motivacion
    public function motivacion(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login');
        }

        //Se crea un informe de la hora de inicio de la prueba
        $reporte = $this->crear_reporte($user);
        if (!$reporte) {
            return redirect()->back()->with('error', 'No se pudo crear el reporte.');
        }
        session(['id_reporte' => $reporte->id_reporte]);


        return view('private.motivacion');
    }


    public function mostrarPrueba()
    {
        $prueba = Pruebas::first();

        if (!$prueba) {
            return redirect()->back()->with('error', 'No hay pruebas disponibles.');
        }

        return view('private.mostrarTest', compact('prueba'));
    }

    public function calificar_pregunta_cerrada(Request $request, $pregunta_id, $user)
    {
        $respuesta_cerrada = $request->input('respuestas_cerradas');

        $opcionSeleccionada = DB::table('opciones')
            ->where('id_pregunta', $pregunta_id)
            ->where('id_opcion', $respuesta_cerrada)
            ->first();

        if (!$opcionSeleccionada) {
            return redirect()->back()->with('error', 'Opción seleccionada no válida.');
        }

        $this->guardarRespuesta($request, $user, $pregunta_id, $opcionSeleccionada->texto, $opcionSeleccionada->valor_opcion);
    }

    public function calificar_pregunta_abierta(Request $request, $pregunta_id, $user)
    {
        if (!$this->isAiScoringEnabled()) {
            $this->guardarRespuesta($request, $user, $pregunta_id, '', 0);
            return;
        }

        $respuestas_abiertas = $request->input('respuestas_abiertas');
        $respuestas_abiertas_texto = reset($respuestas_abiertas);

        if (is_array($respuestas_abiertas)) {
            $respuestas_abiertas = reset($respuestas_abiertas); // Obtén el primer valor del array
        }

        $opcion_seleccionada = $this->selectedClosedOptionId($request);

        $opcion = Opciones::find($opcion_seleccionada);
        if (!$opcion) {
            return redirect()->back()->with('error', 'Opción seleccionada no válida.');
        }

        if ($opcion->valor_opcion == 0) {
            $respuesta_chatgpt = 0;
        } else {

            [$contexto, $pregunta] = $this->obtenerContextoYPregunta($pregunta_id);
            $criterio = Criterios::where('id_pregunta', $pregunta_id)->pluck('texto');

            $opcion_seleccionada = $this->selectedClosedOptionId($request);

            $opcion = Opciones::where('id_opcion', $opcion_seleccionada)->pluck('texto')->first();

            $prompt = "Contexto: " . $contexto . " fin contexto. Esta es la pregunta : " . $pregunta . " fin pregunta. Esta es la opcion seleccionada en el anterior item" . $opcion . "Estos son los criterios para la calificacion " . $criterio . "Fin criterio. Necesito que lo que valla en la respuesta abierta sea coherente con la pregunta que se hace y si no lo es su calificación debe ser 0. Con lo anterior devuélveme el número de la calificación, sin ninguna otra letra, con la siguiente respuesta: " . $respuestas_abiertas_texto;

            $respuesta_chatgpt = $this->openAIService->enviarRespuestaAChatGPT($prompt);

            if ($respuesta_chatgpt == null) {
                //dd("falló chatGPT");
                throw new ChatGPTException('Error en la respuesta de ChatGPT. Por favor, intenta nuevamente.');
            }
        }

        $this->guardarRespuesta($request, $user, $pregunta_id, $respuestas_abiertas, $respuesta_chatgpt);
    }

    public function calificar_subpreguntas_cerradas(Request $request, $pregunta_id, $user)
    {

        $totalCalificacionSubpreguntas = 0;
        $totalSubpreguntas = 0;

        foreach ($request->input('respuestas_cerradas') as $subpregunta => $respuesta) {

            $opcionSubpreguntaSeleccionada = DB::table('opcionessubpreguntas')
                ->where('id_subpregunta', $subpregunta)
                ->where('id_opcionessubpregunta', $respuesta)
                ->first();


            if (!$opcionSubpreguntaSeleccionada) {
                return redirect()->back()->with('error', 'Opción seleccionada no válida para la subpregunta.');
            }

            //guardar respuesta subpregunta en la tabla subrespuestas
            $this->guardarRespuestaSubpregunta($request, $user, $subpregunta, $opcionSubpreguntaSeleccionada->texto, $opcionSubpreguntaSeleccionada->valor_opcion);


            $totalCalificacionSubpreguntas += $opcionSubpreguntaSeleccionada->valor_opcion;
            $totalSubpreguntas++;
        }


        $preguntaPrincipalId = $request->input('pregunta_ids')[0];
        $this->guardarRespuesta($request, $user, $preguntaPrincipalId, 'Calificación basada en subpreguntas', $totalCalificacionSubpreguntas);
    }

    public function calificar_subpreguntas_abiertas(Request $request, $user)
    {
        if (!$this->isAiScoringEnabled()) {
            foreach ((array) $request->input('respuestas_abiertas', []) as $subpregunta_id => $respuesta_abierta) {
                $subpregunta = Subpreguntas::find($subpregunta_id);
                if (!$subpregunta || $subpregunta->tipo_pregunta !== 'abierta') {
                    continue;
                }

                $this->guardarRespuestaSubpregunta($request, $user, $subpregunta->id_subpregunta, '', 0);
            }
            return;
        }


        $totalCalificacionSubpreguntas = 0;
        $totalSubpreguntas = 0;

        $preguntaPrincipalId = $request->input('pregunta_ids')[1];


        [$contexto] = $this->obtenerContextoYPregunta($preguntaPrincipalId);

        $i = 0;

        foreach ($request->input('respuestas_abiertas') as $subpregunta_id => $respuesta_abierta) {

            $respuestas_cerradas = $request->input('respuestas_cerradas');

            $respuestas_cerradas_indexadas = array_values($respuestas_cerradas);
            $subpregunta = Subpreguntas::find($subpregunta_id);


            if (!is_string($respuesta_abierta) || empty(trim($respuesta_abierta))) {
                return redirect()->back()->with('error', 'Por favor ingrese una respuesta válida para la subpregunta.');
            }

            $opcion_seleccionada = $respuestas_cerradas_indexadas[$i];

            $opcion = Opcionessubpreguntas::find($opcion_seleccionada);
            if (!$opcion) {
                return redirect()->back()->with('error', 'Opción seleccionada no válida para la subpregunta.');
            }

            if ($opcion->valor_opcion == 0) {
                $respuesta_chatgpt = 0;
            } else {

                $criterio = Subcriterios::where('id_subpregunta', $subpregunta_id)->pluck('texto');
                $prompt = "Contexto: " . $contexto . " fin contexto. Esta es la pregunta: " . $subpregunta->texto . " Fin pregunta. Esta es la respuesta del enunciado: " . $opcion->texto . ". fin respuesta. Estos son los criterios para la calificación: " . $criterio . " fin criterio. " . "Nota: La respuesta debe tener un sentido coherente con lo que se pregunta en el contexto." . "Con lo anterior devuélveme el número de la calificación, sin ninguna otra letra, con la siguiente respuesta: " . $respuesta_abierta;
                $respuesta_chatgpt = $this->openAIService->enviarRespuestaAChatGPT($prompt);

                if (!is_numeric($respuesta_chatgpt)) {
                    $respuesta_chatgpt = 0;
                }
            }

            //guardar respuesta subpregunta en la tabla subrespuestas
            $this->guardarRespuestaSubpregunta($request, $user, $subpregunta->id_subpregunta, $respuesta_abierta, $respuesta_chatgpt);

            $totalCalificacionSubpreguntas += $respuesta_chatgpt;
            $totalSubpreguntas++;

            if ($totalSubpreguntas == 5) {

                $this->guardarRespuesta($request, $user, $preguntaPrincipalId, 'Calificación basada en subpreguntas abiertas', $totalCalificacionSubpreguntas);
            }

            $i++;
        }
    }

    public function calificar_pregunta_93(Request $request, $user)
    {

        $respuestas_abiertas = $request->input('respuestas_abiertas');
        $respuesta_abierta_texto = reset($respuestas_abiertas);


        $pregunta1Id = $request->input('pregunta_ids')[0];
        $pregunta2Id = $request->input('pregunta_ids')[1];



        $this->calificar_subpreguntas_cerradas($request, $pregunta1Id, $user);

        if (!$this->isAiScoringEnabled()) {
            $this->guardarRespuesta($request, $user, $pregunta2Id, '', 0);
            return;
        }

        $respuestas_cerradas = $request->input('respuestas_cerradas');

        $respuestas_cerradas_indexadas = array_values($respuestas_cerradas);

        $respuesta_cerrada = $respuestas_cerradas_indexadas[1];

        $subopcion = opcionessubpreguntas::find($respuesta_cerrada);
        if (!$subopcion) {
            return redirect()->back()->with('error', 'Opción seleccionada no válida para la subpregunta.');
        }

        if ($subopcion->valor_opcion == 0) {
            $respuesta_chatgpt = 0;
        } else {

            $respuestas_abiertas = $request->input('respuestas_abiertas');
            $respuesta_abierta_texto = reset($respuestas_abiertas);


            [$contexto, $pregunta] = $this->obtenerContextoYPregunta($pregunta2Id);
            $criterio = Criterios::where('id_pregunta', $pregunta2Id)->pluck('texto')->first();


            $prompt = "Contexto: " . $contexto . " fin contexto. Esta es la pregunta : " . $pregunta . " fin pregunta. Esta es la opcion seleccionada en el anterior item" . $subopcion->texto . "Estos son los criterios para la calificacion " . $criterio . "Fin criterio. calificarás la respuesta abierta en función de la información que te entregué en contexto; pregunta; alternativa correcta; criterios. Con lo anterior devuélveme el número de la calificación, sin ninguna otra letra, con la siguiente respuesta: " . $respuesta_abierta_texto;

            $respuesta_chatgpt = $this->openAIService->enviarRespuestaAChatGPT($prompt);
        }
        $this->guardarRespuesta($request, $user, $pregunta2Id, $respuesta_abierta_texto, $respuesta_chatgpt);
    }

    public function calificar_pregunta_101(Request $request, $user)
    {
        $pregunta1Id = $request->input('pregunta_ids')[0];
        $pregunta2Id = $request->input('pregunta_ids')[1];

        $this->calificar_subpreguntas_cerradas($request, $pregunta1Id, $user);

        if (!$this->isAiScoringEnabled()) {
            $this->guardarRespuesta($request, $user, $pregunta2Id, '', 0);
            return;
        }

        //se califica la pregunta abierta con chatgpt

        $respuestas_abiertas = $request->input('respuestas_abiertas');
        $respuestas_abiertas = reset($respuestas_abiertas);

        // Obtener contexto y criterios para la calificación
        [$contexto, $pregunta] = $this->obtenerContextoYPregunta($pregunta2Id);
        $criterio = Criterios::where('id_pregunta', $pregunta2Id)->pluck('texto');


        // Concatenar contexto y criterios para el prompt de la IA
        $prompt = "Contexto: " . $contexto . " fin contexto. Esta es la pregunta : " . $pregunta . " fin pregunta. " . "Estos son los criterios para la calificacion " . $criterio . "Fin criterio. Necesito que lo que valla en la respuesta abierta sea coherente con la pregunta que se hace y si no lo es su calificación debe ser 0. Con lo anterior devuélveme el número de la calificación, sin ninguna otra letra, con la siguiente respuesta: " . $respuestas_abiertas;

        // Llamar a la IA para obtener la calificación
        $respuesta_chatgpt = $this->openAIService->enviarRespuestaAChatGPT($prompt);


        // Guardar o actualizar la respuesta
        $this->guardarRespuesta($request, $user, $pregunta2Id, $respuestas_abiertas, $respuesta_chatgpt);
    }

    public function verificarSiHayRespondidas()
    {
        $user = Auth::user();
        
        $id_reporte = Reportes::where('id_usuario', $user->id_usuario)->value('id_reporte');
        $id_usuario = $user->id_usuario;


        $respuesta = Respuestas::where('id_reporte', $id_reporte)
            ->where('id_usuario', $id_usuario)
            ->with([
                'pregunta' => function ($query) {
                    $query->select('id_pregunta', 'id_contexto');
                }
            ])
            ->orderBy('created_at', 'desc') // Asegúrate de tener un campo de timestamps para ordenar
            ->first();

        if ($respuesta == null) {
            return 0;
        }
        return $respuesta->pregunta->id_contexto;
    }

    public function cargarPreguntas(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Debes iniciar sesión para continuar.');
        }

        $user = Auth::user();
        $hayError = false;

        // Validar si no se han recibido preguntas
        if (!$request->has('pregunta_ids')) {

            session()->forget('error');
            $hora_inicio_prueba = Carbon::now();
            session(['hora_inicio_prueba' => $hora_inicio_prueba]);
            
            $indices = self::ORDEN_INICIAL_CONTEXTO;
            $id_contexto = $this->verificarSiHayRespondidas();
            $posicion = 0;

            if ($id_contexto != 0) {
                $posicion = array_search($id_contexto, $indices) + 1;
                $indices = array_slice($indices, $posicion);
            }

            // Cargar preguntas iniciales
            $prueba_id = $request->input('prueba_id');
            $contextos = Contexto::with('preguntas')->get();


            $contextos_ordenados = [];

            foreach ($indices as $indice) {
                $contexto_encontrado = $contextos->firstWhere('id_contexto', $indice);

                if ($contexto_encontrado) {
                    $contextos_ordenados[] = $contexto_encontrado;
                }
            }

            if (count($contextos_ordenados) == 0) {
                session()->flash('error', 'No hay contextos disponibles para continuar.');
                return redirect()->back();
            }

            $contexto_index = 0;
            $total_contextos = count($contextos_ordenados);
            $preguntas = $contextos_ordenados[$contexto_index]->preguntas;

            session(['contextos_ordenados' => $contextos_ordenados]);

            return $this->renderPruebaPage($preguntas, $contexto_index, $total_contextos, $prueba_id, $posicion);
        }

        // Validar respuestas enviadas
        $pregunta_ids = $request->input('pregunta_ids');
        if (is_array($pregunta_ids)) {
            foreach ($pregunta_ids as $pregunta_id) {
                try {
                    if (in_array($pregunta_id, self::PREGUNTAS_ESPECIALES_93)) {
                        $this->calificar_pregunta_93($request, $user);
                    } elseif (in_array($pregunta_id, self::PREGUNTAS_ESPECIALES_101)) {
                        $this->calificar_pregunta_101($request, $user);
                    } else {
                        $tipo_pregunta = Preguntas::where('id_pregunta', $pregunta_id)->pluck('tipo_pregunta')->first();

                        if ($tipo_pregunta == 'cerrada' && $request->has('respuestas_cerradas')) {
                            $this->calificar_pregunta_cerrada($request, $pregunta_id, $user);
                        }
                        if ($tipo_pregunta == 'abierta' && $request->has('respuestas_abiertas')) {
                            $this->calificar_pregunta_abierta($request, $pregunta_id, $user);
                        }
                        if ($tipo_pregunta == 'subpregunta' && $request->has('respuestas_cerradas')) {
                            $this->calificar_subpreguntas_cerradas($request, $pregunta_id, $user);
                        }
                        if ($tipo_pregunta == 'subpregunta' && $request->has('respuestas_abiertas')) {
                            $this->calificar_subpreguntas_abiertas($request, $user);
                        }
                    }
                } catch (ChatGPTException $e) {
                    session()->flash('error', 'Error en la calificación de la respuesta abierta. Por favor contesta las preguntas y presiona "siguiente" nuevamente.');
                    $hayError = true;
                    break;
                } catch (\Exception $e) {
                    session()->flash('error', 'Ocurrió un error inesperado. Por favor, inténtalo nuevamente.');
                    $hayError = true;
                    break;
                }
            }
        } else {
            session()->flash('error', 'No se recibieron preguntas.');
            return redirect()->back();
        }

        // Si hay un error, no avanzar
        if ($hayError) {

            $contexto_index = $request->input('contexto_index', 0);
            $contexto_index = max(0, $contexto_index);
            $contextos_ordenados = session('contextos_ordenados');
            $preguntas = $contextos_ordenados[$contexto_index]->preguntas;
            $prueba_id = $request->input('prueba_id');
            $posicion = $request->input('posicion', 0);
            $total_contextos = count($contextos_ordenados);

            return $this->renderPruebaPage($preguntas, $contexto_index, $total_contextos, $prueba_id, $posicion);
        }


        //verificarlo posicion
        // Avanzar al siguiente contexto si no hubo errores
        $prueba_id = $request->input('prueba_id');
        $contexto_index = $request->input('contexto_index', 0);
        $posicion = $request->input('posicion', 0) + 1;
        $contexto_index++;
        $total_contextos = Contexto::count();

        if ($posicion >= $total_contextos) {
            $tiempo_en_minutos = $this->currentTestElapsedMinutes();

            return $this->metacognicion($tiempo_en_minutos, session('id_reporte'));
        }

        $contextos_ordenados = session('contextos_ordenados');
        $preguntas = $contextos_ordenados[$contexto_index]->preguntas;

        session()->forget('error');

        return $this->renderPruebaPage($preguntas, $contexto_index, $total_contextos, $prueba_id, $posicion);
    }




    /**
     * Será llamado por primera vez para asociar las preguntas respondidas a ese reporte
     * @return void
     */
    public function crear_reporte($user): Reportes
    {

        $fecha_actual = Carbon::now()->format('Y-m-d');
        $reporte = Reportes::where('id_usuario', $user->id_usuario)
            ->whereDate('fecha_calificacion', '=', $fecha_actual)
            ->first();


        if (!$reporte) {
            $nuevo_reporte = Reportes::create([
                'id_usuario' => $user->id_usuario,
                'fecha_calificacion' => $fecha_actual
            ]);
            session('id_reporte_actual', $nuevo_reporte->id_reporte);
            return $nuevo_reporte;
        }
        session(['id_reporte_actual' => $reporte->id_reporte]);

        return $reporte;
    }

    private function obtenerContextoYPregunta($preguntaId): array
    {
        $id_contexto = Preguntas::where('id_pregunta', $preguntaId)->pluck('id_contexto')->first();
        $contexto = Contexto::where('id_contexto', $id_contexto)->pluck('texto')->first();
        $pregunta = Preguntas::where('id_pregunta', $preguntaId)->pluck('texto')->first();

        return [$contexto, $pregunta];
    }

    private function renderPruebaPage($preguntas, $contexto_index, $total_contextos, $prueba_id, $posicion)
    {
        return view('private.prueba_page', compact('preguntas', 'contexto_index', 'total_contextos', 'prueba_id', 'posicion'));
    }

    private function currentReportId()
    {
        return session('id_reporte');
    }

    private function selectedClosedOptionId(Request $request)
    {
        $respuesta_cerrada = $request->input('respuestas_cerradas');
        return reset($respuesta_cerrada);
    }

    private function currentTestElapsedMinutes()
    {
        $hora_final_prueba = Carbon::now();
        $hora_inicio_prueba = session('hora_inicio_prueba');
        $tiempo_prueba = $hora_final_prueba->diffInSeconds($hora_inicio_prueba);

        return $tiempo_prueba / 60;
    }

    private function isAiScoringEnabled(): bool
    {
        return (bool) config('features.ai_scoring_enabled', false);
    }
}
